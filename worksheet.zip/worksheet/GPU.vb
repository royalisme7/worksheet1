﻿Public Class GPU

End Class
Public Manufacturer;
Public String Name;
